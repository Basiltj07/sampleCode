import { useState, useEffect } from 'react';
import axios from 'axios';


const useApiCall = (props = null) => {

  const [response, setResponse] = useState();
  const [loading, setLoading] = useState(true);



  useEffect(() => {

    const fetchData = async () => {
      // // let response = axios.get('https://quotes.rest/qod?language=en')
      // let response = axios.get('https://quotes.rest/qod?language=en')
      // .then(response => {
      //   setResponse(response);
      // })
      // return response;

      let config = {};  
      config.method = props.method ? props.method : "get";
      config.url = props.url ? props.url : "";                                 
      config.data = props.data ? props.data : {}; 
      const res = await axios(config)
        .then(response => {

          console.log("response : ",response);

          setResponse(res);
        });  
    }

    if(loading){
      setLoading(false)
      fetchData();
    }

  }, [loading, props]);


  return [response];


};



export default useApiCall;
import React , {useEffect,useState} from 'react';
import DataTableComponent from '../../Components/DataTableComponent';
import axios from 'axios';

const  ManageBlogs = ()=>{
	const [tableData, setTableData] = useState([{}])
	useEffect(() => {
		getData();
	}, []);

	const getData = async () => {
		try {
			axios.defaults.baseURL =  "http://localhost:3000";
			axios.get('sampleData.json').then(res => {  

				setTableData(JSON.parse(res.data));
			}).catch((error)=> {
				console.log("Error is: " + error);
			})
		} catch (err) {
			console.log("Error" + err)
		}
    }        
	return (<div>
            <DataTableComponent tbldata= {tableData}/>
            manage
			</div>
	)
};
export default ManageBlogs;

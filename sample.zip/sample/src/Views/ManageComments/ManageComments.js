import React from 'react';
const  ManageComments = ()=>{
  return (<div>
    
    ManageComments


  </div>
  )
};
export default ManageComments;

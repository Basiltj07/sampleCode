import React from 'react';
const  ManageUsers = ()=>{
  return (<div>
    
    ManageUsers


  </div>
  )
};
export default ManageUsers;

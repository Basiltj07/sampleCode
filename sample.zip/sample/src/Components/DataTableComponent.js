import React from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
const DataTableComponent = (props) => {
    debugger
    console.log(props.tbldata)
  // props.tbldata.data.map(col=>{console.log(col.name)})
    return (
    <><div>test</div>
        <div> {(props.tbldata.data && props.tbldata.data.blogData) && 
           <DataTable value={props.tbldata.data.blogData}>
                {props.tbldata.data.columnInfo.length>0&&props.tbldata.data.columnInfo.map((column)=>(
                    <Column
                field={column.field}
                header={column.header}
                />))} </DataTable>
        }
        </div></>
    );
}
export default DataTableComponent
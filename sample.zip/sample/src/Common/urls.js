export const RENDER_URL = {
    SIGN_IN_URL: '/sign-in',
    MANAGE_USERS: '/manage/users',
    MANAGE_BLOGS: '/manage/blogs',
    MANAGE_COMMENTS: '/manage/comments',
};

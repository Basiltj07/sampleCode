import React, { lazy, Suspense } from "react";
import { RENDER_URL } from "../Common/urls";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
const SignInComponent = lazy(() =>
  import("../Views/SignIn")
);
const ManageBlogsComponent = lazy(() =>
  import("../Views/ManageBlogs")
);
const ManageCommentsComponent = lazy(() =>
  import("../Views/ManageComments")
);
const ManageUsersComponent = lazy(() =>
  import("../Views/ManageUsers")
);



const Routes = () => {
  return (
    <Router basename="/">
      <Suspense fallback={<div className="displayNone"> </div>}>
          <Switch>
            <Route
                exact
                path={RENDER_URL.SIGN_IN_URL}
                component={SignInComponent}
              />     
            <Route
                exact
                path={RENDER_URL.MANAGE_USERS}
                component={ManageUsersComponent}
              />
            <Route
                exact
                path={RENDER_URL.MANAGE_BLOGS}
                component={ManageBlogsComponent}
              />       
            <Route
                exact
                path={RENDER_URL.MANAGE_COMMENTS}
                component={ManageCommentsComponent}
              />
          </Switch>
      </Suspense>
    </Router>
  );
};
export default Routes;
